length = input ("type something nice about your self")
for i in range (int(9999)):
    print(length)
print("feel better now?")
